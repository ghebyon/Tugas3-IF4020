package com.fsck.k9.glide;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

@GlideModule
public class K9AppGlideModule extends AppGlideModule {
}
