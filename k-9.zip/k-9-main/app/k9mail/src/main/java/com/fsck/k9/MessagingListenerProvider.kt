package com.fsck.k9

import com.fsck.k9.controller.MessagingListener

class MessagingListenerProvider(val listeners: List<MessagingListener>)
