package com.fsck.k9.controller

class NotificationState {
    @get:JvmName("wasNotified")
    var wasNotified: Boolean = false
}
