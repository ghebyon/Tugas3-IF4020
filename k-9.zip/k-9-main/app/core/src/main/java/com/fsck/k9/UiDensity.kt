package com.fsck.k9

enum class UiDensity {
    Compact,
    Default,
    Relaxed,
}
