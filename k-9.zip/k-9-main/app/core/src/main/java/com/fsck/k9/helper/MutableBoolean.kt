package com.fsck.k9.helper

class MutableBoolean(var value: Boolean)
