package com.fsck.k9.preferences

object Protocols {
    const val IMAP = "imap"
    const val POP3 = "pop3"
    const val WEBDAV = "webdav"
    const val SMTP = "smtp"
}
