package com.fsck.k9;


public interface AccountsChangeListener {
    void onAccountsChanged();
}
