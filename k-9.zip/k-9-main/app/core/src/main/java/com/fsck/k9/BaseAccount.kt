package com.fsck.k9

interface BaseAccount {
    val uuid: String
    val name: String?
    val email: String
}
