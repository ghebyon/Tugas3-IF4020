package com.fsck.k9

fun interface AccountRemovedListener {
    fun onAccountRemoved(account: Account)
}
