package com.fsck.k9.mail

enum class MailServerDirection {
    INCOMING,
    OUTGOING,
}
