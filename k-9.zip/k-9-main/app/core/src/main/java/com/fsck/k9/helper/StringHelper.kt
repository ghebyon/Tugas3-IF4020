@file:JvmName("StringHelper")

package com.fsck.k9.helper

fun isNullOrEmpty(text: String?) = text.isNullOrEmpty()
