package com.fsck.k9.message.html

data class HtmlSettings(
    val useDarkMode: Boolean,
    val useFixedWidthFont: Boolean,
)
