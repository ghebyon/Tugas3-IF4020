package app.k9mail.html.cleaner

interface HtmlHeadProvider {
    val headHtml: String
}
