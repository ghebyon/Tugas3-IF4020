package app.k9mail.ui.catalog

enum class CatalogThemeVariant {
    LIGHT, DARK
}
