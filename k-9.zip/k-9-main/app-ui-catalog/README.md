# Thunderbird UI Catalog

Uses [`:core:ui:compose:designsystem`](../core/ui/compose/designsystem/README.md)

This is a catalog of all the components in the Thunderbird design system.

It is a work in progress, and will be updated as the design system evolves.
